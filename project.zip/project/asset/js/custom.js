$(document).ready(function(){


    
        $(window).scroll(function(){
            let scrolled = $(window).scrollTop();
            let scroll = $(".core_service").outerHeight();   //this is a local variable

            if(scrolled > scroll){
                $(".button_top a").css({
                    "transform": "translateY(0)"

                });
            }else{
                $(".button_top a").css({
                    "transform": "translateY(100px)"
                });
            }
        });

        //this is for my sub menu control
        $(".menu_bar").on("click", function(){
            if($(".sub_menu").hasClass("active")){
                $(".sub_menu").removeClass("active");
            }else{
                $(".sub_menu").addClass("active");
            }
        });

        $(window).scroll(function(){
            let scrolled = $(window).scrollTop();
            let scroll = $(".service_tabs").outerHeight();   //this is a local variable

            if(scrolled > scroll){
                $(".button_topps a").css({
                    "transform": "translateY(0)"

                });
            }else{
                $(".button_topps a").css({
                    "transform": "translateY(100px)"
                });
            }
        });

        $(".container").on("click", function(){
                 $(".sub_menu").removeClass("active");
        });
            
   

    });
