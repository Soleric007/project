
    $("document").ready(function(){

      // $("#title").css("color", "blue");

      $(".service_box").css("background",
        "linear-gradient(45deg, yellow, green)"
      );
      
      $("#service_box").css("background", "linear-gradient(45deg, red, blue, #272626)");
      
      $("#bd_img").css({
        "background-image": "url('./asset/images/businessman.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });
      $("#bgd_img").css({
        "background-image": "url('./asset/images/lapgirl.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });
      $("#bdd_img").css({
        "background-image": "url('./asset/images/lapboy.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });
      $("#bddg_img").css({
        "background-image": "url('./asset/images/checking.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });
      $("#bdgg_img").css({
        "background-image": "url('./asset/images/lapgirl.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });
      $("#service_box").css({
        "background-image": "url('./asset/images/Bank_Vault.jpeg')",
        "background-size": "cover",
        "background-repeat": "no-repeat",
        "color": "yellow"
      });

      $("li:nth-child(1)").prepend("tom is ");
      $("li:nth-child(1)").append(" right here");

      $("li:nth-child(3) a").html("come in");
      $("li:nth-child(4)").hide();
      $("li:nth-child(4)").show();


      $("#title").click(function(){

          // $(this).toggleClass("green");
        
        if($('#title').hasClass('green')){
          $('#title').removeClass('green');
        }else{
          $('#title').addClass('green');
        }
      });


      // $(window).scroll(function(){
      //   if($(this).scrollTop() > 1050){
      //     $("#lower").addClass("green");
      //   }else{
      //     $("lower").removeClass("green");
      //   }
      // });

      //   $(window).scroll(function(){
      //   if($(window).scrollTop() > $("#service_box").offset().top){
      //     $("#lower").addClass("green");
      //   }else{
      //     $("#lower").removeClass("green");
      //   }
      // });

        $(window).on('scroll', function(){
          let x= $(window).scrollTop(); 
          let y= $("#service_box").offset().top;
          
          
          if(x > y){
            $("#lower").addClass("green");
          }else{
            $("#lower").removeClass("green");
          }
        });

      

      
    });
  
  