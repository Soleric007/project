<?php
require('./server/data_source.php');
require('./partials/authentication.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./asset/css/style.css">
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>
<body>
    <?php include('./partials/dashboard_header.php') ?>


    <main class="edit_profile_content">

        <a href="profile.php" class="edp_btn"><i class="fa-solid fa-arrow-left"></i>Back to Profile</a>
        <div class="profile_edit">
            <h1>Update Profile</h1>
            <p>Update your contact information below</p>
        </div>
        <div class="profile_box">
            <form action="./server/update_profile.php" method="POST">
            <div class="update_form_group">
            <label for="email">Email Address</label>
            <input 
            name="email"
            type="email"
            placeholder="Email"
            value="<?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            </div>
            <div class="update_form_group">
            <label for="address">Address</label>
            <input 
            name="address" 
            type="text" 
            placeholder="Address"
            value="<?php echo htmlspecialchars($user['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            </div>
            <div class="update_form_group">
            <label for="phonenumber">Phone Number</label>
            <input 
            name="phonenumber" 
            type="tel" 
            placeholder="Phone Number"
            value="<?php echo htmlspecialchars($user['phonenumber'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"> 
            </div>
            <div class="update_form_group">
            <button name="submit" type="submit">Save Changes</button>
            <a href="profile.php" class="edp_btn">Cancel</a>
            </div>
        </form>
        </div>
        

    </main>



    <footer class="footer_content">
        © 2025 BraveDex. A Trusted & Secured Online Bank.
    </footer>
    
</body>
</html>
