<?php
session_start();

unset($_SESSION['auth_id']);
header(header: 'location:./login.php');
die();
 ?>