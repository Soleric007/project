<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BraveDex| About</title>
    <link rel="stylesheet" href="./asset/css/style.css" />
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
  </head>
  <body>
    <header>
      <a href="index.html"><img class="logo" src="./asset/images/logo.svg" alt="logo" srcset=""></a>
      <nav>
        <ul>
          <li><i class="fa-solid fa-house"></i><a href="./index.php">Home</a></li>
          <li><i class="fa-solid fa-address-card"></i><a href="./about.php">About</a></li>
          <li><i class="fa-solid fa-sliders"></i><a href="./dashboard.php">Dashboard</a></li>
          <li><i class="fa-solid fa-circle-user"></i><a href="./login.php">login</a></li>
          <li><i class="fa-solid fa-registered"></i><a href="./register.php">Register</a></li>
        </ul>
      </nav> 
      <div class="menu_bar">
        <i class="fa-solid fa-bars"></i>
      </div>
    </header>

    <div class="sub_menu">
        <nav>
            <ul>
                <li><i class="fa-solid fa-house" ></i><a href="./index.html">Home</a></li>
                <li><i class="fa-solid fa-address-card"></i><a href="./about.html">About</a></li>
                <li><i class="fa-solid fa-circle-user"></i><a href="./login.html">login</a></li>
                <li><i class="fa-solid fa-registered"></i><a href="./register.html">Register</a></li>
            </ul>
      </nav>
    </div>



     <section class="container">
      <div class="about_us">
        <div class="about_bx">
          <h1>About BraveDex</h1>
          <p>BraveDex is a next-generation online bank created to redefine the way people interact with their money. 
             Our mission is simple <span>"make banking easier, safer, and more accessible to everyone"</span>
             We believe that modern financial services should be fast, transparent, and built around the needs of the customer. 
             BraveDex was developed with this vision at its core.
         </p>
        </div>
        <div class="about_bx">
          <img src="./asset/images/Sales Close Rate Industry Benchmarks_ How Does Your Close Rate Compare_.png" alt="">
        </div>

      </div>
      


      <div class="core_service">
        <h2>Our Philosophy</h2>
        <p style="margin-bottom: 1rem;">At BraveDex, we stand on three major pillars</p>
        <div class="service_tabs">
          <div class="service_box">
            <h3>Trust</h3>
            <p>We are committed to providing reliable services supported by industry-leading security systems, regulated operations, and transparent processes. 
               Trust is not demanded—it is earned.</p>
          </div>
          <div class="service_box">
            <h3>Innovation</h3>
            <p>We constantly improve our technology to deliver smarter solutions, seamless transactions, 
               and a user experience that matches global banking standards.</p>
          </div>
          <div class="service_box">
            <h3>Accessibility</h3>
            <p>Everyone deserves access to quality financial services. BraveDex breaks the barriers of traditional banking by giving you full banking capabilities directly from your phone or computer.</p>
          </div>
          <div class="service_box">
            <h3>Our Vision</h3>
            <p>To become the most trusted and innovative online bank, empowering individuals and businesses worldwide to take control of their financial future</p>
          </div>
          <div class="service_box">
            <h3>Our Promise to You</h3>
            <p>BraveDex is more than a bank,its a partner.
               We are committed to giving you tools that simplify banking, improve financial well-being, and ensure peace of mind at every step.</p>
          </div>
        </div>

        <div class="button_topps">
        <a href="#"><i class="fa fas fa-arrow-up"></i></a>
      </div>
      </div>
        

      <!-- final content of our page -->
        <div class="conclude">
          <div class="bottom_bx" style="background-image: url(./asset/images/lapboy.jpeg); background-repeat: round;">
            <div class="conclude_box"  style="background-color: #053139eb;">
              <h3>What We Offer</h3>
              <li>Fully digital account opening</li>
              <li>Instant money transfers</li>
              <li>Card services (virtual and physical)</li>
              <li>Savings & investment tools</li>
              <li>Business and personal banking options</li>
              <li>Fraud protection and data security</li>
              <li>24/7 customer support</li>
              <li>Simple, clean, and intuitive user interface</li>
                
            </div>
          </div>

          <div class="bottom_bx" style="background-image: url(./asset/images/lapgirl.jpeg); background-repeat: round;">
            <div class="conclude_box" style="background-color: #312a07db;">
              <h3>Our Commitment to Security</h3>
              <p>Your safety is at the heart of everything we do. BraveDex employs:
                <li>End-to-end data encryption</li>
                <li>Two-Factor Authentication (2FA)</li>
                <li>Real-time fraud detection</li>
                <li>Regular system audits</li>
                <li>Secure cloud infrastructure</li>
                 Your money and personal information are protected with world-class security standards.
                </p>
            </div>
          </div>

        </div>
  </section>

      
    <footer>
      <div> © 2025 BraveDex. A Trusted & Secured Online Bank.</div>
    </footer>
  </body>
</html>
  <script src="./asset/js/jQuery.js"></script>
  <script src="./asset/js/custom.js"></script>
