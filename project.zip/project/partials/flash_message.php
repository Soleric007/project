<?php
session_start();

function showError(){
    $message = $_SESSION["error"]?? "";
    echo "<p style = 'color: red'>$message</p>";
    unset($_SESSION["error"]);
};