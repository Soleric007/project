 <div class="info_btn">
    <a href="./login.php">login</a>

    <a href="./register.php">SignUp</a>
</div>