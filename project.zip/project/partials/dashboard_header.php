<header>
      <a href="index.html">
        <img class="logo" src="./asset/images/logo.svg" alt="logo" srcset="">
      </a>
      <nav>
          <ul>
            <li><i class="fa-solid fa-house"></i><a href="./index.php">Home</a></li>
            <li><i class="fa-solid fa-sliders"></i><a href="./dashboard.php">Dashboard</a></li>
            <li><i class="fa-solid fa-address-card"></i><a href="./profile.php">Profile</a></li>
            <li><i class="fa-solid fa-address-card"></i><a href="./about.php">About</a></li>
            <li><i class="fa-solid fa-circle-user"></i><a href="./logout.php">log out</a></li>
          </ul>
      </nav>

      <div class="menu_bar">
        <i class="fa-solid fa-bars"></i>
      </div>
    </header>
    <div class="sub_menu">
        <nav>
            <ul>
              <li><i class="fa-solid fa-house" ></i><a href="./index.html">Home</a></li>
            <li><i class="fa-solid fa-address-card"></i><a href="">Profile</a></li>
              <li><i class="fa-solid fa-address-card"></i><a href="./about.html">About</a></li>
              <li><i class="fa-solid fa-circle-user"></i><a href="./login.html">login</a></li>
              <li><i class="fa-solid fa-registered"></i><a href="./register.html">Register</a></li>
            </ul>
      </nav>
    </div>