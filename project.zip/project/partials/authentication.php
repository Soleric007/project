<?php 

if(session_status() == PHP_SESSION_NONE) session_start();

$islogin = $_SESSION['auth_id']?? false;

if($islogin == false){
    $_SESSION['error'] = "Please Provide your Login Details";
    header(header: 'location: ./login.php');
    die();
}

$user = getAuthUser($_SESSION['auth_id']);

?>