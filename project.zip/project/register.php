<?php 
include("./partials/flash_message.php"); 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BraveDex | Sign up</title>
    <link rel="stylesheet" href="./asset/css/style.css" /> 
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
  </head>
  <body
    style="
      background-image: url('./asset/images/Wallpapers\ for\ Room\ -\ WallpaperSafari.jpeg');
      background-size: cover;
    "
  >
    <header>
      <a href="index.html"><img class="logo" src="./asset/images/logo.svg"></a>
      <nav>
        <ul>
          <li><i class="fa-solid fa-house"></i><a href="./index.php">Home</a></li>
          <li><i class="fa-solid fa-address-card"></i><a href="./about.php">About</a></li>
          <li><i class="fa-solid fa-sliders"></i><a href="./dashboard.php">Dashboard</a></li>
          <li><i class="fa-solid fa-circle-user"></i><a href="./login.php">login</a></li>
          <li><i class="fa-solid fa-registered"></i><a href="./register.php">Register</a></li>
        </ul>
      </nav>
    </header>
    <section class="container_log pd-top">
      <div class="login_box">
        <div class="intro_log">
          <h1>Welcome to BraveDex!</h1>
          <p>please enter your details</p>
          <?php showError(); ?>
        </div>

        <form action="./server/process_register.php" method="POST">
          <div class="form-group">
            <label style="display: flex;" for="fullname">Full Name</label>
            <input name="fullname" type="text" placeholder="surname | first-name | last-name" />
          </div>
          <div class="form-group">
            <label style="display: flex;" for="date">Date of birth</label>
            <input name="date" type="text" placeholder ="MM/DD/YY"/>
          </div>
          <div class="form-group">
            <label style="display: flex;" for="address">Address</label>
            <input name="address" type="address" placeholder="address" />
          </div>
          <div class="form-group">
            <label style="display: flex;" for="Phone_Number">Phone Number</label>
            <input name="Phone_Number" type="Phone Number" placeholder="phone number" />
          </div>
          <div class="form-group">
            <label style="display: flex;" for="email">Email</label>
            <input name="email" type="email" placeholder="Email" />
          </div>
          <div class="form-group">
            <label style="display: flex;" for="password">Password</label>
            <input name="password" type="password" placeholder="Password" />
          </div>
          <div class="form-group">
            <label style="display: flex;" for="Confirm_Password">Confirm Password</label>
            <input name="Confirm_Password" type="password" placeholder="Confirm Password" />
          </div>
          <div class="form-group">
            <button name="submit" type="submit">Sign Up</button>
          </div>
        </form>
        <div class="reg">
          <h4>Already a member? <a href="./login.html">sign in</a></h4>
        </div>
      </div>
    </section>

    <footer>
      <div> © 2025 BraveDex. A Trusted & Secured Online Bank.</div>
    </footer>
  </body>
</html>
