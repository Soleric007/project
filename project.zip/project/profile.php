<?php
require('./server/data_source.php');
require('./partials/authentication.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./asset/css/style.css">
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>
<body>
    <?php include('./partials/dashboard_header.php') ?>

    <main class="profile_container">

      <div>
          <h1>Profile</h1>
      </div>


	      <div class="profile_card">
	        <div class="profile_upload">
	          <i class="fa-solid fa-circle-user"></i>
	        </div>
	        <div class="profile_details">
	          <div class="row">
	            <strong>Full Name</strong>
	            <span><?php echo htmlspecialchars($user['fullname'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="row">
            <strong>Address</strong>
            <span><?php echo htmlspecialchars($user['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="row">
            <strong>Email Address</strong>
            <span><?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
         </div>
          <div class="row">
            <strong>Date of Birth</strong>
            <span><?php echo htmlspecialchars($user['dateofbirth'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="row">
	            <strong>Phone Number</strong>
	            <span><?php echo htmlspecialchars($user['phonenumber'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span>
	         </div>

	        </div>
	      </div>

	  <a href="edit_profile.php" class="edit_btn">
	    Edit Profile
	  </a>
      
</main>
<footer>
  <div> © 2025 BraveDex. A Trusted & Secured Online Bank.</div>
</footer>
    
</body>
</html>
 <!-- <script src="./asset/js/jQuery.js"></script>
  <script src="./asset/js/custom.js"></script> -->
