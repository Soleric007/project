<?php
require('./server/data_source.php');
require('./partials/authentication.php');
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brave Dex</title>
    <link rel="stylesheet" href="./asset/css/style.css" />
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>
<body>
    <?php include('./partials/dashboard_header.php') ?>


    <main class="dashboard-content">

        <div>
            <h1>Good Morning, <?php echo $user['fullname']?></h1>
            <p>Here is what happening to your money today</p>
        </div>

        <div class="cards">
            <div class="card">
                <h3><span class="card-icon"><i class="fa-solid fa-wallet"></i><span class="percent"> +2.4% </span></h3>
                <p><span>Total Balance</span> <br>$48,250.80</p>
            </div>
            <div class="card">
                <h3><span class="card-icon"><i class="fa-solid fa-arrow-down"></i> <span class="percent"> +8.1% </span></h3>
                <p><span>Income</span> <br>$12,840.00</p>
            </div>
            <div class="card">
                <h3><span class="card-icon"><i class="fa-solid fa-square-arrow-up-right"></i> <span class="percents"> -3.2% </span></h3>
                <p><span>Spending</span> <br>$5,210.45</p>
            </div>
            <div class="card">
                <h3><span class="card-icon"><i class="fa-solid fa-chart-line"></i> <span class="percent"> +5.6% </span></h3>
                <p><span>Investment</span> <br>$21,900.00</p>
            </div>
        </div>

    </main>



    <footer class="footer-content">
        <div> © 2025 BraveDex. A Trusted & Secured Online Bank.</div>
    </footer>
</body>
</html>
  <script src="./asset/js/jQuery.js"></script>
  <script src="./asset/js/custom.js"></script>