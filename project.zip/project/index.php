<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BraveDex| Home</title>
    <link rel="stylesheet" href="./asset/css/style.css" />
    <link rel="shortcut icon" href="./asset/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
  </head>
  <body>
    <!-- header is here -->
      <?php isset($_SESSION['auth_id']) ? include('./partials/dashboard_header.php') : include("./partials/header.php"); ?>
      

        <section class="container">
      <div style="border-radius: 7px; background-image: url(./asset/images/businessman.jpeg); background-repeat: round;">
      <div class="intro">
          <h1>Welcome to BraveDex</h1>
          <p>
            BraveDex is a modern digital banking platform built to give you complete control over your finances anytime, anywhere. With cutting-edge security, fast transactions, and a user-first experience, BraveDex empowers you to bank with confidence.
          </p> 
         <?php isset($_SESSION['auth_id']) ? "" : include("./partials/users_form.php"); ?>
     </div>

      </div>
     <div class="content">
        <div class="bx">
          <h2 id="title">Why Choose BraveDex?</h2>
          <p>
            At BraveDex, we combine innovation and trust to deliver banking that works for you. 
            Whether you're saving, investing, or making daily transactions, our platform ensures a seamless and secure experience every step of the way.
          </p>
        </div>
        <div class="bx">
          <div class="tom">BX</div>
          <div class="boxt"></div>
        </div>
     </div>


     <!-- The service box that BraveDex provides -->
    <div class="core_service">
      <h2>Our Core Services</h2>

        <div class="service_tabs">
          <div class="service_box" id="service_box">
            <h3>Digital Accounts</h3>
            <p>
              Open and manage your account online within minutes. 
              Enjoy easy access to your funds, automated statements, and real-time notifications.
            </p>
          </div>
          <div class="service_box" id="bdgg_img">
            <h3>Secure Money Transfers</h3>
            <p>
              Send and receive money instantly. BraveDex supports local and international transfers with top-tier encryption for maximum safety.
            </p>
          </div>
          <div class="service_box" id="bddg_img">
            <h3>Savings & Investment Plans</h3>
            <p>
                Grow your wealth with tailored savings options and investment opportunities designed to match your financial goals.
          </p>
          </div>
          <div class="service_box" id="bdd_img">
            <h3>Virtual & Physical Debit Cards</h3>
            <p>
                Shop online or in-store using your BraveDex debit card. 
                Activate, freeze, or manage your card easily through your dashboard.
            </p>
          </div>
          <div class="service_box" id="bgd_img">
            <h3>Bill Payments & Utilities</h3>
            <p>
                Pay your bills, recharge airtime, and handle subscriptions quickly—all from one place.
            </p>
          </div>
          <div class="service_box" id="bd_img">
            <h3>24/7 Customer Support</h3>
            <p>
                Our dedicated support team is always available to assist you with any questions or concerns.
            </p>
          </div>
        </div>
    

    </div>

        <!-- final content of our page -->
        <div class="conclude">
          <div class="bottom_bx" style="background-image: url(./asset/images/lapboy.jpeg); background-repeat: round;">
            <div class="conclude_box"  style="background-color: #053139eb;">
              <h3 id="lower">Built on Trust and Security</h3>
              <p> 
                  At BraveDex, your security is our priority.
                  We use advanced encryption, multi-layer authentication, and real-time fraud monitoring to keep your funds and personal information safe.
                  With BraveDex, your banking is protected and reliable—every single day.
              </p>
            </div>
          </div>

          <div class="bottom_bx" style="background-image: url(./asset/images/lapgirl.jpeg); background-repeat: round;">
            <div class="conclude_box" style="background-color: #312a07db;">
              <h3>Join Thousands Banking with Confidence</h3>
              <p>
                Start your journey with BraveDex today and experience a smarter, faster, and safer way to bank.
              </p>
            </div>
          </div>

        </div>
        </section>
        <div class="button_top">
        <a href="#"><i class="fa fas fa-arrow-up"></i></a>
      </div>

    <footer>
      <div> © 2025 BraveDex. A Trusted & Secured Online Bank.</div>
    </footer>
  </body>
</html>
  <script src="./asset/js/jQuery.js"></script>
  <script src="./asset/js/custom.js"></script>