<?php
session_start();
include('./data_source.php');

$id = $_SESSION['auth_id'];

$email = trim($_POST['email'] ?? '');
$address = trim($_POST['address'] ?? '');
$phonenumber = trim($_POST['phonenumber'] ?? '');

$result = updateUser($id, $email, $address, $phonenumber);
header('location:../profile.php');
die();
?>
