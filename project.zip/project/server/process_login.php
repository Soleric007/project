<?php 
session_start();
include('./data_source.php');


$check_email = isset($_POST['email']);
$check_password = isset($_POST['password']);

if($check_email == false || empty($_POST['email'])){
    $_SESSION["error"] = 'Please provide Your email';
    header(header: 'location:../login.php');
    die();
}

if($check_password == false || empty($_POST['password'])){
    $_SESSION["error"] = 'Please provide Your password';
    header(header: 'location:../login.php');
    die();
}

$email = $_POST['email'];
$password = $_POST['password'];

$check = login($email, $password);

if($check == false){
    $_SESSION["error"] = 'invalid login details';
    header(header: 'location:../login.php');
    die();
    
}
else {
    $_SESSION["auth_id"] = $check;
    header(header: 'location:../dashboard.php');
}
    