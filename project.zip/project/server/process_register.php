<?php
session_start();
include("./data_source.php");


$check_fullname = isset($_POST['fullname']);
$check_date = isset($_POST['date']);
$check_address = isset($_POST['address']);
$check_phoneNumber = isset($_POST['Phone_Number']);
$check_email = isset($_POST['email']);
$check_password = isset($_POST['password']);
$check_confirmPassword = isset($_POST['Confirm_Password']);



if($check_fullname == false || empty($_POST['fullname'])){
    $_SESSION["error"] = 'Please provide Your fullname';
    header(header: 'location:../register.php');
    die();
}

if($check_date == false || empty($_POST['date'])){
    $_SESSION["error"] = 'Please provide Your birthdate';
    header(header: 'location:../register.php');
    die();
}

if($check_address == false || empty($_POST['address'])){
    $_SESSION["error"] = 'Please provide Your address';
    header(header: 'location:../register.php');
    die();
}
if($check_phoneNumber == false || empty($_POST['Phone_Number'])){
    $_SESSION["error"] = 'Please provide Your phone number';
    header(header: 'location:../register.php');
    die();
}

if($check_email == false || empty($_POST['email'])){
    $_SESSION["error"] = 'Please provide Your email';
    header(header: 'location:../register.php');
    die();
}

if($check_password == false || empty($_POST['password'])){
    $_SESSION["error"] = 'Please provide Your password';
    header(header: 'location:../register.php');
    die();
}

if($check_confirmPassword == false || empty($_POST['Confirm_Password'])){
    $_SESSION["error"] = 'Please confirm Your password';
    header(header: 'location:../register.php');
    die();
}


if($_POST['password'] !== $_POST['Confirm_Password']){
    $_SESSION["error"] = 'Password does not match';
    header(header: 'location:../register.php');
    die();
}

$fullname = $_POST['fullname'];
$dateofbirth = $_POST['date'];
$address = $_POST['address'];
$phonenumber = $_POST['Phone_Number'];
$email = $_POST['email'];
$password = $_POST['password'];


if(emailExists($email)){
    $_SESSION["error"] = 'Email already exists';
    header(header: 'location:../register.php');
    die();
}

$hide_password = password_hash($password, PASSWORD_DEFAULT);
$id = registerNewUser($fullname, $dateofbirth, $address, $phonenumber, $email, $hide_password);
$_SESSION['auth_id'] = $id;
header(header: 'location:../dashboard.php');
