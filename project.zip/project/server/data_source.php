<?php
function getDataSource(){
    $conn = mysqli_connect(hostname: "127.0.0.1", username: "root", password: "", database: "brave dex");
    return $conn;
    };


//     $db = getDataSource();

// if ($db != true) {
//     echo "database is not connected";
// } else {
//     echo "connection established";
// }

function emailExists($email)
{
    $db = getDataSource();

    $all_emails = $db->query(query: "select email, password from users")->fetch_all();
    $all_emails = array_column($all_emails, column_key: 0);
    return in_array($email, $all_emails);
}

function registerNewUser($fullname, $dateofbirth, $address, $phonenumber, $email, $password)
{
    $db = getDataSource();
    $db->query(query: "insert into users (fullname, dateofbirth, address, phonenumber, email, password) values ('$fullname', '$dateofbirth', '$address', '$phonenumber', '$email', '$password')");
    return $db->insert_id;
}

function login($email,$password){
    $db = getDataSource();
    $user = $db->query(query: "select id, password from users where email='$email'")->fetch_assoc();
    if($user == null) return false;
    if(password_verify($password, hash: $user['password'])) return $user['id'];
    return false;
}

function getAuthUser($id){
    $db = getDataSource();
    $user = $db->query(query: "select * from users where id = '$id'")->fetch_assoc();
    return $user;
}

function updateUser($id, $email, $address, $phonenumber){
    $db = getDataSource();
    return $db->query("UPDATE users SET email= '$email' , address='$address' , phonenumber= '$phonenumber' where id ='$id'");
 
}


?>